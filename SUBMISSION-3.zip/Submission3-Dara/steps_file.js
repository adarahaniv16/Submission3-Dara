/* eslint-disable no-undef */
/* eslint-disable func-names */

module.exports = function () {
  return actor({

  });
};
